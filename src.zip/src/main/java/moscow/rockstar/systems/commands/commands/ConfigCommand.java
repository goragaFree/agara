package moscow.rockstar.systems.commands.commands;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import moscow.rockstar.Rockstar;
import moscow.rockstar.systems.commands.Command;
import moscow.rockstar.systems.commands.CommandBuilder;
import moscow.rockstar.systems.commands.CommandContext;
import moscow.rockstar.systems.commands.ParameterValidator;
import moscow.rockstar.systems.commands.ValidationResult;
import moscow.rockstar.systems.config.ConfigFile;
import moscow.rockstar.systems.config.ConfigManager;
import moscow.rockstar.systems.localization.Localizator;
import moscow.rockstar.utility.game.MessageUtility;
import net.minecraft.text.Text;

public final class ConfigCommand {
   private static final ParameterValidator<String> CONFIG_NAME = ValidationResult::ok;

   public Command command() {
      List<String> configNames = Rockstar.getInstance().getConfigManager().getConfigFiles().stream().map(ConfigFile::getFileName).toList();
      return CommandBuilder.begin(
            "config",
            b -> b.aliases("cfg", "кфг", "конфиг")
               .desc("commands.config.description")
               .<ConfigCommand.Action>param(
                  "action",
                  p -> p.validator(text -> {
                        Optional<ConfigCommand.Action> action = ConfigCommand.Action.from(text);
                        return action.isPresent() ? ValidationResult.ok(action.get()) : ValidationResult.error(Localizator.translate("commands.config.invalid_action"));
                     })
                     .suggests(ConfigCommand.Action.allNames())
                )
               .<String>param("id", p -> p.optional().validator(CONFIG_NAME).suggests(configNames))
               .handler(this::handle)
         )
         .build();
   }

   private void handle(CommandContext ctx) {
      ConfigCommand.Action action = (ConfigCommand.Action)ctx.arguments().get(0);
      String id = (String)ctx.arguments().get(1);
      action.createHandler().accept(id);
   }

   private enum Action {
      SAVE("save", "create", "add", "сохранить", "ыфму"),
      REMOVE("delete", "remove", "del", "удалить", "вудуеу"),
      LIST("list", "дшые"),
      LOAD("load", "use", "использовать", "дщфв"),
      DIR("dir", "direction");

      private final List<String> names;

      Action(String... names) {
         this.names = Arrays.stream(names).map(String::toLowerCase).collect(Collectors.toList());
      }

      private Consumer<String> createHandler() {
         return switch (this) {
            case SAVE -> this::saveConfig;
            case REMOVE -> s -> {
               if (s != null) {
                  Rockstar.getInstance().getConfigManager().getConfig(s).delete();
               }
            };
            case LIST -> s -> Rockstar.getInstance().getConfigManager().listConfigs();
            case LOAD -> s -> {
               Rockstar.getInstance().getConfigManager().refresh();
               if (s != null && Rockstar.getInstance().getConfigManager().getConfig(s) != null) {
                  Rockstar.getInstance().getConfigManager().getConfig(s).load();
               }
            };
            case DIR -> s -> Rockstar.getInstance().getConfigManager().directionConfig();
         };
      }

      private void saveConfig(String configName) {
         if (configName != null) {
            ConfigManager configManager = Rockstar.getInstance().getConfigManager();
            configManager.createConfig(configName);
            MessageUtility.info(Text.of(Localizator.translate("commands.config.saved", configName)));
         }
      }

      static Optional<ConfigCommand.Action> from(String input) {
         String key = input.toLowerCase();
         return Arrays.stream(values()).filter(a -> a.names.contains(key)).findFirst();
      }

      static List<String> allNames() {
         return Arrays.stream(values()).map(a -> (String)a.names.getFirst()).collect(Collectors.toList());
      }
   }
}
