package moscow.rockstar.systems.modules.api;

public enum ModuleCategory {
   COMBAT,
   MOVEMENT,
   VISUALS,
   PLAYER,
   OTHER;
}
