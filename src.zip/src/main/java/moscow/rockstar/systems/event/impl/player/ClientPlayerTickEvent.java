package moscow.rockstar.systems.event.impl.player;

import moscow.rockstar.systems.event.Event;

public class ClientPlayerTickEvent extends Event {
}
