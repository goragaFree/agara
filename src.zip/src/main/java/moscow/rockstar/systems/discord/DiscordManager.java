package moscow.rockstar.systems.discord;

import moscow.rockstar.utility.interfaces.IMinecraft;

public class DiscordManager implements IMinecraft {
   public void connect() {
   }
}
